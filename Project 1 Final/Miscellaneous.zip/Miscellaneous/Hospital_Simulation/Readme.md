Program instructions are as follows:

The program simulates a hospital waiting room. A person inputs a patient's name, priority number, and ailment into the computer. Once they are done, the program then allows the "nurse" to pull patients by 1) priority and then 2) order of arrival. The program also prints the list of all patients when done. 

This program uses Arrays of pointers instead of a singular linked list to simulate the priority queue, and was done as a practice excercise for a class.

Instructions:
Type "g++ -o main *.cpp" to compile
Type ./main to run


