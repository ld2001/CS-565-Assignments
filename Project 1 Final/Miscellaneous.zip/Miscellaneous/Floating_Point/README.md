This is a programming assignment, done in C, for the New Beginnings program. 

Overview-
Programming Language: C
Assignment Purpose: Simulate a floating point calculator. The user provides the number of exp bits, number of frac bits, and the hex value, and program provides the result of the floating point calculation.
Usage Details:
	To make the file, type make.
	To run the file, type "./main (exp bits) (frac bits) (8 bit hex value)"
Further Details:
	Full programming instructions provided in the Instructions.md file


