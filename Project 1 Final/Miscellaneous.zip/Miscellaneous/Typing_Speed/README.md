This is a programming assignment, done in C, for the New Beginnings program. 

Overview-
Programming Language: C
Assignment Purpose: Test the user's typing speed. The user will be asked to type ten words. Once the user types ten words (correctly), the program will then return the time and uniseconds that it took the user to type.
Usage Details:
	To make the file, type make.
	To run the file, type "./main"
Further Details:
	Full programming instructions provided in the Instructions.md file


