The file is a superstructor that combines the properties of queues and stacks, allowing a user to:
	a) Push on top of a stack
	b) Pop the item off the stack
	c) Enqueue an item
	d) Dequeue an item
	e) In order insert into a LinkedList

List is the superstructure to the Node class.

Type "g++ -o main *.cpp" to compile.
Type ./main to run
